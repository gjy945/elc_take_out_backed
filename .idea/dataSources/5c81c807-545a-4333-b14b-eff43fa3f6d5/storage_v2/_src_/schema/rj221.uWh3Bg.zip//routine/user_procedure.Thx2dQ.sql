create
    definer = root@localhost procedure user_procedure(IN input_gender varchar(2), OUT num int)
BEGIN
    -- 临时存储变量，用于存放统计结果
    DECLARE count_gender INT;

    -- 执行统计查询，并将结果赋值给临时变量
    SELECT COUNT(*) INTO count_gender FROM users WHERE gender = input_gender;

    -- 将统计结果赋值给输出参数
    SET num = count_gender;
END;

